TODO
=====

* Update README adding configuration
* Write tests for:
 * Diazo transformations
 * POST:
  * GET attributes
  * Using `multipart/form-data` mime
  * Using `application/x-www-form-urlencoded`
  * Using `text/plain`
  * Using `application/octet-stream`
  * Using a broken content-type
