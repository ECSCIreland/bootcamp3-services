
Changelog
---------

.. include:: ../CHANGELOG.rst
